package org.masque.qq.demo.vo;

/**
 * 
 * <p>Project: Masque's Base</p>
 * <p>Description: 返回登陆信息状态</p>
 * <p>Copyright (c) 2014 Masque.All Rights Reserved.</p>
 * @author <a href="masque.java@gmail.com">Masque</a>
 */
public class LoginStatusVo {
	public static void main(String[] args) {
		String str = "";
		Object o = (Object)str;
		System.out.println(o=="");
	}
}
