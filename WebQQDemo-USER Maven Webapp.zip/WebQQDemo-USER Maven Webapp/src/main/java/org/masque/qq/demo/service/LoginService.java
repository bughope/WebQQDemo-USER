package org.masque.qq.demo.service;

public interface LoginService {

}
