package org.masque.qq.demo.service.impl;

import org.masque.qq.demo.service.LoginService;

public class LoginServiceImpl implements LoginService {

}
