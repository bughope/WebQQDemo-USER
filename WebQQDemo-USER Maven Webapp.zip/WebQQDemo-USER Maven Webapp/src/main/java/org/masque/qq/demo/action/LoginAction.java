package org.masque.qq.demo.action;

import org.masque.qq.demo.base.BaseAction;

/**
 * 
 * <p>Project: Masque's Base</p>
 * <p>Description: </p>
 * <p>Copyright (c) 2014 Masque.All Rights Reserved.</p>
 * @author <a href="masque.java@gmail.com">Masque</a>
 */
public class LoginAction extends BaseAction{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	public String execute() {
		System.out.println("-------------------------------------------");
		return null;
	}
}
