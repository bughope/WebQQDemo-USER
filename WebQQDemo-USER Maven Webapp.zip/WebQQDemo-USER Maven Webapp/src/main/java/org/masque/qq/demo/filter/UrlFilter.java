package org.masque.qq.demo.filter;

public class UrlFilter {

}
