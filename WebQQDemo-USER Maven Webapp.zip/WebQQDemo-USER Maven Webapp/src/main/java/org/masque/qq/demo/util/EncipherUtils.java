package org.masque.qq.demo.util;

public class EncipherUtils {

	
	
}
