package org.masque.qq.demo.domain;
/**
 * 
 * <p>Project: Masque's Base</p>
 * <p>Description: 记录请求登陆的日志</p>
 * <p>Copyright (c) 2014 Masque.All Rights Reserved.</p>
 * @author <a href="masque.java@gmail.com">Masque</a>
 */
public class LoginLogVo {

}
